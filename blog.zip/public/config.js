/**
 * 全局配置（通常是后端的 URL 配置）
 * 前端在业务代码通过访问 window.CONFIG 来访问此配置
 */
window.CONFIG = {
  login: 'https://192.168.1.1/login'
};
