import Classification from '@/views/classification';

export default {
  path: '/aboutMe',
  name: 'aboutMe',
  component: Classification,
  meta: {
    label: '关于我'
  }
};
