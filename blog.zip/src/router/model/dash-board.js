import DashBoard from '@/views/dashboard';
export default {
  path: '/',
  name: 'dashboard',
  component: DashBoard,
  meta: {
    label: '首页'
  }
};
