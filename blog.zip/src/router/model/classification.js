import Classification from '@/views/classification';

export default {
  path: '/classification',
  name: 'classification',
  component: Classification,
  meta: {
    label: '分类'
  }
};
