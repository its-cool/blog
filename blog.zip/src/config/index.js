export const GLOBAL_CONFIG = window.CONFIG; // 来自 public/config.js 中
