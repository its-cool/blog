<template>
  <div class="full">
    <div class="class-box">
      sdfdsfsdfsdfsddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd
    </div>
  </div>
</template>

<script>
export default {
  name: 'index',
  data() {
    return {
      show: true
    };
  },
  methods: {}
};
</script>

<style lang="scss" scoped></style>
