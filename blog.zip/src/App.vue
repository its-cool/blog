<template>
  <div id="app" class="full-height">
    <router-view></router-view>
  </div>
</template>

<script>
export default {
  name: 'app'
};
</script>

<style lang="scss" scoped></style>
