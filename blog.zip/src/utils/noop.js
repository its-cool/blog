/**
 * 空函数
 * @description
 * 用于默认的函数参数
 */
export default function noop() {}
