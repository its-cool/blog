<template>
  <div class="header">
    <h1>熊成龙个人博客</h1>
  </div>
</template>

<script>
export default {};
</script>

<style lang="scss" scoped>
@import '~@/styles/common-variables.scss';

.header {
  background: $color-info;
  color: white;
  height: $header-height;
}
</style>
